from audioop import reverse
from operator import truediv

#
# birth = '1/6/1952'
# print(birth.split('/'))

#
# marxes = ['qro', 'srot', 'prot']
# marxes.append('Liliya')
# others = ['emir', 'albina']
# marxes.insert(0,'Lena')
# marxes.insert(3, 'jiji')
# # marxes.extend(others)
# # marxes += others
# del marxes[-1]
# marxes.remove('Lena')
# marxes.pop()
# marxes.pop(1)
# print(marxes)



#
# names = ['lera', 'alla', 'kamila', 'albina', 'kamila' ]
#
# # print(names.index('alla'))
#
# print('albina' in names)
# print(names.count('kamila'))
# print(';'.join(names))



#
# num = [3,4,9,6,1,5,8]

# num.sort()
# print(num)
#





#
# friends = ['hatty', 'lena', 'vadim', 'alena']
#
# sorted_freds = sorted(friends)
# print(sorted_freds)
# friends.sort()
#

# sep = '*'
# joind = sep.join(friends)
# print(joind)









#
# empty_list = []
# weekdays = ['monday', 'thuesday', 'wednesday', 'thursday', 'friday']
# big_birds = ['emu', 'ostrich', 'cassowary']
# first_names = ['Graham', 'John', 'Terry', 'Terry', 'Michael']
#
# another_empty_list = list()
# print(another_empty_list)
#
# print(list('cat'))
#
# a_tuple = ('ready', 'fire', 'aim')
# print(list(a_tuple))

#
# birth = '1/6/1956'
# print(birth.split('/'))

















#
# students = ['bilal', 'dair', 'aidana', 'ulan','gana']
# print(students)
#
#



'''' delete'''
#
# students.remove('dair')
# deleted = students.pop(-1)
# del students [:2]
# students.clear()
#
# print(students)
# print(deleted)



# #
# ''''' edit'''
#
# students.sort()  # сортирует по алфавиту
# students.reverse()  # переворачивает
# students[0] = 'Albina'  # изменения по индексу
#
# print(students)



#






''' add'''
'''' edit'''
''''' delete'''
#
# students.append('sergey')  #добовляет один обьект в конец списка
# students.insert(2,'ali')#добовляет один обьект в определенное место
# students.extend(['marat', 'kamila']) # добовляет несколько обьектов в конец списка







# print(students[0])
# print(students[2])
# print(students[-1])
# print(students[-2])
#
#
# print(students[1:3:1])
# print(students[:2])
# print(students[::2])









#
# numbers = [23, 45, 67, 89, 90, 10]
#
##
# print(len(numbers))
# print(min(numbers))
# print(max(numbers))
# print(sum(numbers))
# print(any(numbers))
# print(all(numbers))










# students = ['bilal', 'dair', 'aidana', 'ulan', 'pasha']
#




# students.remove('dair')
#
# deleted = students.pop(-1)
# del students[:2]
# students.clear()
#
#
# print(students)
# students.reverse()
# students.sort()
#
# students[0] = 'abdel'





#
# students.append('Albina')
# students.insert(2,'ali')
# students.extend('marat','kamila')
#
# print(students)






#
# print(students[0])
# print(students[2])
# print(students[-2])
# print(students[-1])
#
#
# # [start:stop:step]
# print(students[1:3:1])
# print(students[:2])
# print(students[::2])
#
#





