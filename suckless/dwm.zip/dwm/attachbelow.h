#ifndef ATTACHBELOW_H
#define ATTACHBELOW_H

extern int attachbelow;
void loadAttachBelow();
void saveAttachBelow();

#endif

